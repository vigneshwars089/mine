﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Configuration;
using System.Data.SqlClient;


namespace next.Models
{
    public class nextClass1
    {
        public int PersonID { get; set; }
        public string Account { get; set; }
        public string Project { get; set; }
        public string Process { get; set; }

        public string SubProcess { get; set; }
        public int Counts { get; set; }

        //private bool connection_open;



        public nextClass1()
        {

            SqlConnection Dbase = new SqlConnection();

            using (Dbase)
            {
                //
                // Open the SqlConnection.
                //
                Dbase.Open();
                //
                // The following code uses an SqlCommand based on the SqlConnection.
                //
                using (SqlCommand command = new SqlCommand("SELECT TOP 1 * FROM dbo.graphfirst", Dbase))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("{0} {1} {2}",
                            reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(2), reader.GetInt32(4));

                        Account = reader.GetString(0);
                        Project = reader.GetString(1);
                        Process = reader.GetString(2);
                        SubProcess = reader.GetString(3);
                        Counts = reader.GetInt32(4);

                    }
                }
                //    m_Person = new CPersonMaster();
                //  List<CPersonMaster> PersonList = new List<CPersonMaster>();
                //PersonList = CComs_PM.Fetch_PersonMaster(connection, 4, arg_id);

                //if (PersonList.Count==0)
                //  return "";

                //m_Person = PersonList[0];

                //DB_Connect.CloseTheConnection(connection);
                /*try
                {
        

                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;
                    cmd.CommandText =string.Format("select concat (person_id, ') ', surname, ', ', forename) Person, Address1, Address2, photo, length(photo) from PersonMaster where Person_ID = '{0}'",
                                                  PersonID);

                    SqlDataReader reader = cmd.ExecuteReader();

                    try
                    {
                        reader.Read();

                        if (reader.IsDBNull(0) == false)
                            Name = reader.GetString(0); 
                        else
                            Name = null;

                        if (reader.IsDBNull(1) == false)
                            Address1 = reader.GetString(1); 
                        else
                            Address1 = null;

                        if (reader.IsDBNull(2) == false)
                            Address2 = reader.GetString(2); 
                        else
                            Address2 = null;

                        if (reader.IsDBNull(3) == false)
                                {
                                    Photo = new byte[reader.GetInt32(4)];
                                    reader.GetBytes(3, 0, Photo, 0, reader.GetInt32(4));
                                }
                                else
                                {	
                                    Photo = null;
                                }
                        reader.Close();

                    }
                    catch (SqlException e)
                    {
                        string  MessageString = "Read error occurred  / entry not found loading the Column details: "
                            + e.ErrorCode + " - " + e.Message + "; \n\nPlease Continue";
                        //MessageBox.Show(MessageString, "SQL Read Error");
                        reader.Close();
                        Name= MessageString;
                        Address1 = Address2 = null;
                    }
                }
                catch (SqlException e)
                {
                        string  MessageString = "The following error occurred loading the Column details: "
                            + e.ErrorCode + " - " + e.Message;
                        Name= MessageString;
                        Address1 = Address2 = null;
                    }*/







            }
        }
    }
}